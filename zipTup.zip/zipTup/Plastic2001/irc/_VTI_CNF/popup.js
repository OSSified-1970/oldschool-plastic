vti_encoding:SR|utf8-nl
vti_author:SR|Administrator
vti_modifiedby:SR|Administrator
vti_timecreated:TR|15 Dec 2000 01:46:44 -0000
vti_timelastmodified:TR|15 Dec 2000 01:59:34 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|15 Dec 2000 01:46:46 -0000
vti_extenderversion:SR|4.0.2.4317
vti_syncwith_www.geocities.com\:80/artificial_plastic:TR|15 Dec 2000 01:59:34 -0000
vti_syncofs_ftp.geocities.com\:21/artificial_plastic:TW|16 Feb 2001 21:16:00 -0000
vti_syncwith_ftp.geocities.com\:21/artificial_plastic:TR|15 Dec 2000 01:59:34 -0000
vti_syncwith_ftp.geocities.com\:21:TR|15 Dec 2000 01:59:34 -0000
vti_syncofs_ftp.geocities.com\:21:TW|03 Jan 2002 03:22:00 -0000
