vti_encoding:SR|utf8-nl
vti_author:SR|Administrator
vti_timecreated:TR|07 Jan 2000 19:03:25 -0500
vti_syncwith_10203040\\c\:\\temp\\1:TR|07 Jan 2000 19:03:25 -0500
vti_modifiedby:SR|Administrator
vti_backlinkinfo:VX|javaproject/hello10/index.html
vti_extenderversion:SR|3.0.2.926
vti_timelastmodified:TR|08 Jan 2000 00:03:26 -0000
vti_syncwith_www.geocities.com\:80/artificial_plastic:TR|08 Jan 2000 00:03:26 -0000
vti_nexttolasttimemodified:TR|07 Jan 2000 19:03:25 -0500
vti_syncofs_ftp.geocities.com\:21/artificial_plastic:TW|16 Feb 2001 21:16:00 -0000
vti_syncwith_ftp.geocities.com\:21/artificial_plastic:TR|08 Jan 2000 00:03:26 -0000
vti_syncwith_ftp.geocities.com\:21:TR|08 Jan 2000 00:03:26 -0000
vti_syncofs_ftp.geocities.com\:21:TW|03 Jan 2002 03:22:00 -0000
