/**
Hello9.java

  This applet lets one repeatedly enter a number
  and then prints out four strings on separate
  lines separated by a vertical distance specified
  by the number.

  The applet gives online instructions and helps the
  user correct errors made in selecting the numbers to 
  input.
*/
import java.io.*; //Imports like "#includes" in C language.
import java.awt.*;
import java.applet.*;
public class Hello9 extends Applet //Name the Hello9 class being described.
{
		int x=10, //x-coordinate
			y=50, //y-coordinate
			iNum, //input line-spacing variable
			iFlag=0; //shows what operation paint() will perform when called.
			String  sOutString1="First", //Strings to be output at various times.
				sOutString2="Second",
                sOutString3="Third",
                sOutString4="Fourth",
                sPlease="Please enter a new spacing number between",
                sPlease2="10 and 70 and click the button.",
                sPlease3="-------------------------------",
				sErrorMsg1="The number was TOO LARGE.",
				sErrorMsg2="The number was TOO SMALL.",
				sErrorMsg3="Try again.",		
				sUnexpected="Something very unexpected happened!!!",		
                sLabel="Enter a Number:"; //String for label for text entry box
			TextField inputField = new TextField(2); //Specify text entry box.
			Button Enter = new Button("Enter"); //Specify enter button.
		
		public void init() //Setup applet window at startup
		{
            add(new Label(sLabel)); //Draw text entry box label
			add(inputField); //Draw text entry box
            add(Enter); //Draw enter button
		}

		
		public void paint(Graphics gA) //Method to run when the applet window is first
		{							   //drawn or when the window is uncovered.
			switch (iFlag)			   //Choose with thing to do based on what flag says
			{
				case 1: //Do this when the number entered is ok and when it is not the 
				{		//first time paint() is called.
					x=10;
					y=50;
					gA.drawString(sPlease, x, y);
					y+=15;
					gA.drawString(sPlease2, x, y);
					y+=15;
					gA.drawString(sPlease3, x, y);
					y+=20;
					gA.drawString(sOutString1, x, y);
					y+=iNum;
					gA.drawString(sOutString2, x, y);
					y+=iNum;
					gA.drawString(sOutString3, x, y);
					y+=iNum;
					gA.drawString(sOutString4, x, y);
					y+=iNum;
					return;
				}
			
				case 2: //Do this when the number entered is too large.
				{
                    x=10;
                    y=50;
                    gA.drawString(sPlease, x, y);
                    y+=15;
                    gA.drawString(sPlease2, x, y);
                    y+=20;
                    gA.drawString(sErrorMsg1, x, y);
                    y+=15;
                    gA.drawString(sErrorMsg3, x, y);
                    y+=15;
                    gA.drawString(sPlease3, x, y);
					return;
				}
				
				case 3: //Do this when the number entered is too small.
				{
                    x=10;
                    y=50;
					gA.drawString(sPlease, x, y);
                    y+=15;
					gA.drawString(sPlease2, x, y);	
                    y+=20;
                    gA.drawString(sErrorMsg2, x, y);
                    y+=15;
                    gA.drawString(sErrorMsg3, x, y);
                    y+=15;
                    gA.drawString(sPlease3, x, y);
					return;
				}
				
	
				case 0: //Do this the first time paint() is called, when the
				{		//applet is started.
					x=10; 
					y=50;
					gA.drawString(sPlease, x, y);
                    y+=15;
					gA.drawString(sPlease2, x, y);
                    y+=15;
                    gA.drawString(sPlease3, x, y);
				}
				
				default: //Other cases, which should not exist.
				{
					return;
				}
			}
		}

		public boolean action(Event evt, Object what) //What to do when the enter
		{											  //button is pressed.
            if (evt.target == Enter) 
			{ 
				String sNum = inputField.getText(); //Read number string from text entry box.
				iNum = Integer.parseInt(sNum); //Convert string to integer.
				if (iNum < 10) //Is the number too small?
				{
					iFlag=3;
					repaint();
					return false;
				}
				if (iNum > 70) //Is the number too large?
				{
					iFlag=2;
					repaint();
					return false;
				}
				iFlag=1; //The number is just right.
				repaint();
			}
			return true;
		}
}
