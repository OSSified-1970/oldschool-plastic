#include <iostream>

using namespace std;


class SelfCounting
{
	static int count;
	
	public:
	SelfCounting();
	~SelfCounting();
};


int SelfCounting::count = 0;

SelfCounting::SelfCounting()
{
	cout << "Constructing SelfCounting " << ++count << endl;
}

SelfCounting::~SelfCounting()
{
	cout << "Destructing SelfCounting " << count-- << endl;
}

int main()
{
	SelfCounting sc1;
	SelfCounting sc2;
	SelfCounting sc3;
	return 0;
}

