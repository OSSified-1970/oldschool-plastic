/* Program to generate prime numbers
 *
 * by Jason Lindsay Crockett
 *
 * copyright 2020
 */

public class Primes {

 // Top of range to probe for primes/
static final long MAX = 1000;

    public static void main(String[] args) {
 
        System.out.println("/* Program to generate prime numbers"
        + " *\n"
        + " * by Jason Lindsay Crockett\n"
        + " *\n"
        + " * copyright 2020\n"
        + " */\n");

       System.out.println(2 + " is a prime number");  
 
       for(long i=3; i <= MAX; i++) {
            boolean boolIsPrime = true;
            for(long j = i - 1; j >= 2; j--) {
                if(i%j == 0) {
                    boolIsPrime = false;
                    break;
                }
            }
            if(boolIsPrime)
                System.out.println(i + " is a prime number");
        }
        System.out.println("End of program.");
    }
}
