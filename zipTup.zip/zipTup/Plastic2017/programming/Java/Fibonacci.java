/* Program to generate a Fibonacci series.
 * 
 * by Jason Lindsay Crockett
 *
 * copyright 2020
 */
 
import java.math.BigInteger;

public class Fibonacci {
 
 static int intArgInt;
 static BigInteger[] numbers; // BigInteger objects will self-manage and
          // probably mostly get compressed and written to
          // virtual memory, if needed.
 public static void main(String[] args) {

   Print.print("/* Program to calculate a Fibonacci series.\n"
             + " *\n"
             + " *\n"
             + " * by Jason Lindsay Crockett\n"
             + " *\n"
             + " * copyright 2020\n"
             + " */\n");
 

  // Code to process the command line arguments
  
  // Only one argument is allowed
  if (args.length != 1) {
    Print.print("You must provide one argument (a single positive integer) on the command line.");
    return;
  }
  // The command line argument must be an integer
  else {
   // Try to parse argument
   try {
    intArgInt = Integer.parseInt(args[0]);
   }
   // Catch exception
   catch (NumberFormatException e) {
    Print.print("You must provide a positive integer as a single argument on "
      + "the command line. You entered " + args[0] 
      + " on the command line.");
    return;
   } 
  }  
  // Make sure argument is positive
  if (intArgInt < 1) {
   Print.print("You must provide a POSITIVE integer as a single argument on "
     + "the command line. You entered " + args[0] 
     + " on the command line.");
   return;
  }
  
  // OK, command line argument was alright. 
  // Prepare to generate Fibonacci numbers.
  Print.print("You made it through the first part of the program."
    + " The command line argument was OK.");
  
  // Default case
  Print.print("0: 1");
  Print.print("1: 1");
  
  //Not default case
  if (intArgInt > 1) {
   numbers = new BigInteger[intArgInt + 1]; // Allocate array of references
   numbers[0] = new BigInteger("1"); // Constructors takes String arguments
   numbers[1] = new BigInteger("1");
 for(int x = 2; x <= intArgInt; x++) {
     numbers[x] = numbers[x-2].add(numbers[x-1]);
     Print.print(x + ": " + numbers[x]);
   }
  }
 Print.print("End of program.");
 }
}

//Helper class: let the compiler make it inline, if needed.
class Print {
    static void print(String str) {
        System.out.println(str);
    }
}